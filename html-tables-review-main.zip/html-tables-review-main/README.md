# Final Project (preview)

Link: https://jasheloper.github.io/html-tables-review/

<br>

![Structuring Planet Data final project preview](planets-data-preview.png)



<br>

## Objective
To test comprehension of HTML tables and associated features.


<br>

## Project Guidelines
https://developer.mozilla.org/en-US/docs/Learn/HTML/Tables/Structuring_planet_data
